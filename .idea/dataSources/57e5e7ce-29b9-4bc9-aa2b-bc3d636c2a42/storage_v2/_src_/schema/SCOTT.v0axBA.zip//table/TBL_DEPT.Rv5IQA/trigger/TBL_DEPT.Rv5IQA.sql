create trigger TBL_DEPT
  before insert
  on TBL_DEPT
  for each row
declare
  -- local variables here
begin
  select dept_sq.nextval into :new.dept_id from dual;
end tbl_dept;
/

