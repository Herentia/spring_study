create trigger TBL_EMP
  before insert
  on TBL_EMP
  for each row
declare
  -- local variables here
begin
  select emp_sq.nextval into :new.emp_id from dual;
end tbl_emp;
/

