create procedure page_info
       (pageno in integer, pagesize in integer, total out Integer, emps out sys_refcursor) 
       is
begin
  select count(*) into total from tbl_emp;
  open emps for
       select * from (select rownum rn, e.* from tbl_emp e where rownum<=pagesize) 
               where rn>=pageno;
end page_info;
/

